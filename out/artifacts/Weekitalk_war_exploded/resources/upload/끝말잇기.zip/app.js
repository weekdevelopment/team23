$(document).ready(function() {
    var lastWord = "";  // 마지막 단어 저장 변수
    var score = 0;  // 점수 저장 변수
    var chatBody = $('.chat-body');
  
    // 메시지 추가 함수
    function addMessage(message, isUser) {
      var className = isUser ? 'user' : 'chatbot';
      var $messageBubble = $('<div class="message-bubble"></div>');
      $messageBubble.addClass(className);
      $messageBubble.text(message);
      var $messageRow = $('<div class="message-row"></div>');
      $messageRow.append($messageBubble);
      chatBody.append($messageRow);
      chatBody.scrollTop(chatBody[0].scrollHeight);
    }
  
    // 단어의 유효성을 확인하는 함수
    function isWordValid(word) {
      var url = 'https://api.dictionaryapi.dev/api/v2/entries/en/' + word;
      $.get(url, function(response) {
        if (response.length > 0) {
          var meanings = response[0]['meanings'];
          if (meanings.length > 0) {
            return true;
          }
        }
        return false;
      });
    }
  
    // 끝말잇기 게임 시작
    addMessage('끝말잇기를 시작합니다!', false);
    addMessage('제가 먼저 시작할게요.', false);
    addMessage('apple', false);
    lastWord = 'apple';
  
    $('#send-message').on('click', function() {
      var message = $('#input-message').val().trim();
      alert(isWordValid(message));
      if (message.length > 0) {
        if (lastWord == '') {
          addMessage('시작하는 단어입니다.', false);
        } else if (lastWord[lastWord.length - 1] == message[0]) {
          if (isWordValid(message)) {
            addMessage('잘했어요!', true);
            score++;
          } else {
            addMessage('유효한 단어가 아닙니다!', true);
            score--;
          }
        } else {
          addMessage('끝말잇기 규칙에 어긋납니다!', true);
          score--;
        }
        addMessage(message, true);
        lastWord = message;
        $('#input-message').val('');
        $('#score').text('Score: ' + score);
      }
    });
  
    $('#input-message').on('keypress', function(event) {
      if (event.which === 13) {
        $('#send-message').click();
      }
    });
  });
  