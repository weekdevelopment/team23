$(document).ready(function() {
  var words = ["사과", "바나나", "딸기", "포도", "수박", "참외", "메론", "귤", "망고", "오렌지", "레몬", "키위", "자두", "복숭아", "파인애플", "망고스틴"];
  var lastWord = "";
  var score = 0;
  var chatBody = $('.chat-body');

  // 메시지 추가 함수
  function addMessage(text, isBot) {
    var className = isBot ? 'chat-message-bot' : 'chat-message-user';
    chatBody.append('<div class="chat-message ' + className + '">' + text + '</div>');
    chatBody.scrollTop(chatBody.prop("scrollHeight"));
  }

  // 랜덤 단어 선택 함수
  function chooseRandomWord()
